package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JpaStarter {
	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.setCity("chenn");
		e.setEmpId(103);
		e.setEmpName("suraj");
		e.setSalary(20000);
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		EmployeeService service = (EmployeeService)context.getBean("employeeService");
		service.addEmployee(e);
		System.out.println("rec inserted");
	}

}
