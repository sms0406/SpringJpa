package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDao dao;
	
	@Transactional
	public void addEmployee(Employee e) {
		dao.addEmployee(e);
	}

}
