package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
	@PersistenceContext
	EntityManager em;
	public void addEmployee(Employee e) {
		em.persist(e);
	}

}
